#ifndef BYTECODE_GENERATOR_H
#define BYTECODE_GENERATOR_H

void generate_bytecode() {
    
}

#endif